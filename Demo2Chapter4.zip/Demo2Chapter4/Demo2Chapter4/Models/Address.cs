﻿namespace Demo2Chapter4.Models
{
    public class Address
    {
        public string City { get; set; }
        public string Street { get; set; }
    }
}
