﻿namespace Demo2Chapter4.Models
{
    public enum Category
    {
        Book,
        Magazire,
        EBook
    }
}
